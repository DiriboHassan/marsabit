from django.apps import AppConfig


class FllocaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flloca'
